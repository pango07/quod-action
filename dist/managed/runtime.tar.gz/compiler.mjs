// Research compiler. Preparation always runs; this module grants no replay.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import assert from 'node:assert/strict'
import {builtinModules, createRequire, isBuiltin} from 'node:module'
import {fileURLToPath} from 'node:url'
import {build, version as esbuildVersion} from 'esbuild'

const here = path.dirname(fileURLToPath(import.meta.url))
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex')
// The opt-in certified factory checks this module-evaluation observation;
// a later constructor read alone must not relabel cached compiler code.
export const MANAGED_COMPILER_LOADED_IDENTITY = Object.freeze({
  compilerSha256: sha(fs.readFileSync(fileURLToPath(import.meta.url))),
  esbuildAPI: import.meta.resolve('esbuild'), esbuildVersion,
})
const reserved = 'quod:compiler-capabilities'
const nativeModules = new Set(builtinModules.map(name => name.replace(/^node:/, '')))
const isNative = name => name.startsWith('node:') || nativeModules.has(name) || isBuiltin(name)
const isALS = name => name === 'node:async_hooks' || name === 'async_hooks'
const privateSpecifier = name => name.startsWith('quod:') || name.startsWith('__QUOD_')
const inside = (root, file) => file === root || file.startsWith(root + path.sep)
const slash = value => value.replaceAll('\\', '/')
// Exact published, lock-integrity-reviewed Zod util modules and their optional
// evaluator capability probes. The managed runtime has no dynamic evaluator;
// choose the library's existing interpreter path without attempting/catching a
// prohibited capability. Actual evaluator calls keep all existing denials.
const zodUtilAdapters = new Map([
  ['4614d999e6a5b5a8bbdc0d3033647dbb7ea73f2594394224a145d9c43721c7ba', '85cbd8672064ea19f41dda8eb4565596afb3be3ce10a739fd64ee9b59a41ef22'],
  ['c9dab88c4e7977e4ef0c536c07ef74515333050088bef04dbe871bb92f4a9a2d', '85cbd8672064ea19f41dda8eb4565596afb3be3ce10a739fd64ee9b59a41ef22'],
  ['94d18b95a0fe1194758a8426f331f4e37a2d3a733ec64effe513265ecc963378', '85cbd8672064ea19f41dda8eb4565596afb3be3ce10a739fd64ee9b59a41ef22'],
  ['e41f9e774b96a9fe2b04c08f5aad32e6db2f6aa090671d2a375e7062b4f178aa', '85cbd8672064ea19f41dda8eb4565596afb3be3ce10a739fd64ee9b59a41ef22'],
  ['968e3433e810cf7ba5efb609a1cb6d9a6cfb51215fd1f699938228f7ac25deb3', '8cd1a4f347c3d874337e22f0c9f9781d9b9d2de264f8345a96679f026f061c7f'],
  ['e50c63d70e8b1abf2968936acf22c9e4e96e735f0af6d367785e0948e46553fa', '09f707d71b847ffc1c2af9ae9347df9b06a9302ef5cf3a3c5d292cdacb10e9cd'],
  ['bb08133b11b478c8e715038fff26ebea204d7fd5443fba31fe138b142d202efb', '09f707d71b847ffc1c2af9ae9347df9b06a9302ef5cf3a3c5d292cdacb10e9cd'],
])

// Keys must be independent of insertion order. Values that JSON would silently
// omit, coerce or invoke (including toJSON) are not admitted configuration.
export function canonicalManagedJSON(value) {
  function visit(item) {
    if (item === null || typeof item === 'string' || typeof item === 'boolean') return item
    if (typeof item === 'number') {
      assert(Number.isFinite(item) && !Object.is(item, -0), 'non-canonical configuration number')
      return item
    }
    assert(typeof item === 'object', 'configuration must contain JSON values only')
    if (Array.isArray(item)) {
      assert.equal(Object.getOwnPropertySymbols(item).length, 0, 'symbol configuration keys unsupported')
      assert.equal(Object.getOwnPropertyNames(item).length, item.length + 1, 'sparse/custom arrays unsupported')
      const result = []
      Object.setPrototypeOf(result, null)
      for (let index = 0; index < item.length; index++) {
        const descriptor = Object.getOwnPropertyDescriptor(item, String(index))
        assert(descriptor?.enumerable && 'value' in descriptor, 'configuration array accessors unsupported')
        result[index] = visit(descriptor.value)
      }
      return result
    }
    assert(Object.getPrototypeOf(item) === Object.prototype || Object.getPrototypeOf(item) === null,
      'configuration must contain plain objects')
    assert.equal(Object.getOwnPropertySymbols(item).length, 0, 'symbol configuration keys unsupported')
    const result = Object.create(null)
    for (const key of Object.getOwnPropertyNames(item).sort()) {
      const descriptor = Object.getOwnPropertyDescriptor(item, key)
      assert(descriptor.enumerable && 'value' in descriptor, 'configuration accessors/non-enumerable keys unsupported')
      result[key] = visit(descriptor.value)
    }
    return result
  }
  return JSON.stringify(visit(value))
}

// The real compiler and the diagnostic certificate verifier share this exact
// resolver. A resolver-only check never loads or bundles the resolved modules.
async function ordinaryManagedResolution(builder, fromProject, vitestRoot, zodAlias, args) {
  let resolved
  const requested = zodAlias && /^zod(?=\/|$)/.test(args.path)
    ? zodAlias + args.path.slice(3) : args.path
  if (/^(vitest(?:\/.*)?|vite\/module-runner|chai|tinybench|expect-type)$/.test(args.path)) {
    resolved = {path: args.path === 'vitest' ? path.join(vitestRoot, 'dist/index.js') : fromProject.resolve(args.path)}
  } else {
    resolved = await builder.resolve(requested, {importer: args.importer, resolveDir: args.resolveDir,
      kind: args.kind, namespace: 'file', pluginData: {managedDefaultResolution: true}})
    if (resolved.errors.length) return resolved
    assert(!resolved.external, 'unreviewed external module: ' + args.path)
    assert(!resolved.suffix, 'module query/hash loaders unsupported: ' + args.path)
  }
  return {path: fs.realpathSync(resolved.path)}
}

/** Diagnostic only: one new resolver-only esbuild build checks a suite's edges. */
export async function resolveManagedImports({project: projectArg, requests}) {
  const project = fs.realpathSync(path.resolve(projectArg))
  const fromProject = createRequire(path.join(project, 'package.json'))
  const vitestRoot = path.dirname(fromProject.resolve('vitest/package.json'))
  assert(Array.isArray(requests) && requests.length <= 100000, 'bounded resolver requests required')
  const results = []
  await build({stdin: {contents: 'export {};', resolveDir: project, sourcefile: 'quod-resolve-only.mjs'},
    absWorkingDir: project, write: false, bundle: true, platform: 'browser', format: 'esm', target: 'es2022',
    keepNames: true, plugins: [{name: 'managed-certificate-resolver-only', setup(builder) {
      builder.onStart(async () => {
        for (const request of requests) {
          assert(request.zodAlias === null || /^zod-4\.[0-6]$/.test(request.zodAlias), 'unreviewed resolver alias')
          const result = await ordinaryManagedResolution(builder, fromProject, vitestRoot, request.zodAlias, request)
          assert(!result.errors?.length, 'certificate import no longer resolves: ' + request.path)
          results.push(result.path)
        }
      })
    }}]})
  return results
}

/**
 * The returned compile(entry, options, testFile?) replaces the original probe's
 * compile function. entry is one of the reviewed adapters in adapterRoot.
 * Result metadata retains esbuild's original paths for artifact inspection;
 * identity is the canonical, hashable preparation record.
 */
export function createManagedCompiler({project: projectArg, adapterRoot = here, sourceTreeCache = true}) {
  const project = fs.realpathSync(path.resolve(projectArg))
  const root = fs.realpathSync(path.resolve(adapterRoot))
  const fromProject = createRequire(path.join(project, 'package.json'))
  const ts = fromProject('typescript')
  const compilerSha256 = sha(fs.readFileSync(fileURLToPath(import.meta.url)))
  const prelude = fs.realpathSync(path.join(root, 'prelude.mjs'))
  const entries = new Set(['runner.mjs', 'preflight.mjs', 'native-outbound.mjs', 'boundary-fixture.mjs', 'protector-fixture.mjs'])
  const vitestRoot = path.dirname(fromProject.resolve('vitest/package.json'))
  const moduleName = file => inside(project, file) ? '/project/' + slash(path.relative(project, file))
    : inside(root, file) ? '/quod-adapter/' + slash(path.relative(root, file)) : '/external/' + slash(file)
  // Only source syntax trees are memoized, within this compiler instance.
  // Every caller still reads and hashes the current full source bytes, performs
  // all import resolutions and glob discovery, and parses the final bundle.
  // A timestamp, inode, previous closure or cached module is never authority.
  const trees = new Map()
  let buildSequence = 0
  const treeCache = {enabled: sourceTreeCache === true, hits: 0, crossBuildHits: 0, misses: 0, evictions: 0,
    retainedSourceBytes: 0, finalBundleParses: 0, limitEntries: 128, limitSourceBytes: 8 * 1024 * 1024,
    maxEntrySourceBytes: 512 * 1024}
  assert(typeof sourceTreeCache === 'boolean', 'explicit boolean source-tree cache setting required')
  const readTree = (file, contents, buildId) => {
    const bytes = Buffer.byteLength(contents, 'utf8')
    const finalBundle = file === 'managed-output.mjs'
    const cacheable = treeCache.enabled && !finalBundle && bytes <= treeCache.maxEntrySourceBytes
    const key = cacheable ? file + '\0' + sha(contents) : null
    if (key && trees.has(key)) {
      const record = trees.get(key)
      // LRU ordering affects memory use only. Cached ASTs are never edited.
      trees.delete(key); trees.set(key, record); treeCache.hits++
      if (record.lastBuild !== buildId) treeCache.crossBuildHits++
      record.lastBuild = buildId
      return record.tree
    }
    if (finalBundle) treeCache.finalBundleParses++
    else treeCache.misses++
    const tree = ts.createSourceFile(file, contents, ts.ScriptTarget.Latest, true,
      /\.tsx$/.test(file) ? ts.ScriptKind.TSX : /\.jsx$/.test(file) ? ts.ScriptKind.JSX
        : /\.[cm]?ts$/.test(file) ? ts.ScriptKind.TS : ts.ScriptKind.JS)
    assert.equal(tree.parseDiagnostics.length, 0, 'module parse failed: ' + moduleName(file))
    if (key) {
      while (trees.size >= treeCache.limitEntries || treeCache.retainedSourceBytes + bytes > treeCache.limitSourceBytes) {
        const oldest = trees.keys().next().value
        treeCache.retainedSourceBytes -= trees.get(oldest).bytes
        trees.delete(oldest); treeCache.evictions++
      }
      trees.set(key, {tree, bytes, lastBuild: buildId}); treeCache.retainedSourceBytes += bytes
    }
    return tree
  }
  const unparen = node => {
    while (ts.isParenthesizedExpression(node)) node = node.expression
    return node
  }
  const literal = node => {
    node = unparen(node)
    return ts.isStringLiteralLike(node) ? node.text : null
  }
  const importMeta = node => ts.isMetaProperty(node) && node.keywordToken === ts.SyntaxKind.ImportKeyword
  const metaMember = (node, name) => {
    node = unparen(node)
    return ts.isPropertyAccessExpression(node) && importMeta(unparen(node.expression)) && node.name.text === name ||
      ts.isElementAccessExpression(node) && importMeta(unparen(node.expression)) && literal(node.argumentExpression) === name
  }
  const evaluator = node => {
    node = unparen(node)
    if (ts.isBinaryExpression(node) && node.operatorToken.kind === ts.SyntaxKind.CommaToken) return evaluator(node.right)
    if (ts.isIdentifier(node)) return ['eval', 'Function', 'AsyncFunction', 'GeneratorFunction', 'AsyncGeneratorFunction'].includes(node.text)
    if (ts.isPropertyAccessExpression(node)) return ['eval', 'Function', 'AsyncFunction', 'GeneratorFunction', 'AsyncGeneratorFunction'].includes(node.name.text)
    if (ts.isElementAccessExpression(node)) return ['eval', 'Function', 'AsyncFunction', 'GeneratorFunction', 'AsyncGeneratorFunction'].includes(literal(node.argumentExpression))
    return false
  }

  return async function compile(entry, options, testFileArg) {
    assert(entries.has(entry), 'unreviewed managed entry adapter: ' + entry)
    const buildId = ++buildSequence
    const entryFile = fs.realpathSync(path.join(root, entry))
    const testFile = testFileArg ? fs.realpathSync(testFileArg) : null
    assert(!testFile || (inside(project, testFile) && !inside(root, testFile)), 'test entry must be inside project')
    const optionsJSON = canonicalManagedJSON(options)
    // This is a finite adapter for the reviewed original Zod projects, not a
    // general alias/plugin interpreter. Apply it to dependencies as well as
    // tests so zod-compare and helper imports use the actual project version.
    const zodAlias = options?.zodAlias ?? null
    if (zodAlias !== null) {
      assert(entry === 'runner.mjs' && typeof zodAlias === 'string' && /^zod-4\.[0-6]$/.test(zodAlias), 'unreviewed managed Zod alias')
      assert.equal(options.vitest?.name, zodAlias, 'Zod alias differs from actual project')
      assert.deepEqual(options.providedContext, {expectedZodAlias: zodAlias}, 'Zod context differs from alias')
    } else if (options?.providedContext !== undefined) {
      assert.deepEqual(options.providedContext, {}, 'unreviewed managed provided context')
    }
    const started = performance.now(), globs = [], adapters = [], transforms = [], sources = [], resolutions = [], resolutionFacts = [], injected = new Set()
    const fact = (phase, args, target, route) => {
      const source = args.namespace === 'quod-managed-als' ? '/virtual/public-async-local-storage'
        : args.importer ? moduleName(fs.realpathSync(args.importer)) : null
      resolutionFacts.push({phase, source, specifier: args.kind === 'entry-point' ? moduleName(target) : args.path,
        kind: args.kind, route, target: route === 'ordinary' ? moduleName(target) : target, zodAlias})
    }
    const trusted = new Set([entryFile, prelude])
    const publicALS = new Set()
    const compiled = await build({
      entryPoints: [entryFile], absWorkingDir: project, bundle: true,
      write: false, platform: 'browser', format: 'esm', target: 'es2022', metafile: true, keepNames: true,
      define: {__QUOD_CONFIG__: optionsJSON},
      // An unhandled require/import warning is a preparation failure, rather
      // than a dynamically resolved module accidentally reaching execution.
      logOverride: {'unsupported-dynamic-import': 'error', 'unsupported-require-call': 'error'},
      plugins: [{name: 'managed-closed-module-boundary', setup(builder) {
        const ordinaryResolution = args => ordinaryManagedResolution(builder, fromProject, vitestRoot, zodAlias, args)
        const privateAdapterAllowed = (importer, target, specifier, kind) =>
          kind === 'entry-point' && target === entryFile ||
          trusted.has(importer) && target === prelude && specifier === './prelude.mjs'
        builder.onResolve({filter: /.*/}, async args => {
          if (args.pluginData?.managedDefaultResolution) return
          if (args.namespace === 'quod-managed-als') {
            assert.equal(args.path, 'quod:als-implementation')
            fact('emitted', args, moduleName(prelude), 'als-implementation')
            return {path: prelude}
          }
          const importer = args.importer && fs.realpathSync(args.importer)
          if (args.path === reserved) {
            assert(injected.has(importer), 'private managed helper import is not generated')
            fact('emitted', args, moduleName(prelude), 'injected-helper')
            return {path: prelude}
          }
          if (args.path === '__QUOD_TEST_ENTRY__') {
            assert(importer === entryFile && entry === 'runner.mjs' && testFile && args.kind === 'dynamic-import',
              'private test entry import is not a reviewed adapter')
            fact('emitted', args, moduleName(testFile), 'test-entry')
            return {path: testFile}
          }
          assert(!privateSpecifier(args.path), 'private managed module namespace')
          if (isNative(args.path)) {
            if (importer === prelude && args.path === 'node:async_hooks' && args.kind === 'import-statement') {
              fact('emitted', args, 'node:async_hooks', 'native-als')
              return {path: args.path, external: true}
            }
            assert(isALS(args.path) && args.kind === 'import-statement' && publicALS.has(importer),
              'unsupported native module: ' + args.path)
            fact('emitted', args, '/virtual/public-async-local-storage', 'public-als')
            return {path: 'public-async-local-storage', namespace: 'quod-managed-als'}
          }
          const resolved = await ordinaryResolution(args)
          if (resolved.errors?.length) return resolved
          const real = resolved.path
          fact('emitted', args, real, 'ordinary')
          if (inside(root, real)) {
            assert(privateAdapterAllowed(importer, real, args.path, args.kind),
              'project module cannot import a private managed adapter: ' + args.path)
          }
          resolutions.push({source: importer ? moduleName(importer) : null,
            specifier: args.kind === 'entry-point' ? moduleName(real) : args.path,
            kind: args.kind, target: moduleName(real)})
          return {path: real}
        })
        builder.onLoad({filter: /.*/, namespace: 'quod-managed-als'}, () => ({
          contents: 'export {ManagedAsyncLocalStorage as AsyncLocalStorage} from "quod:als-implementation";\n', loader: 'js',
        }))
        builder.onLoad({filter: /\.[cm]?[jt]sx?$/, namespace: 'file'}, async args => {
          const file = fs.realpathSync(args.path)
          let contents = fs.readFileSync(file, 'utf8')
          const sourceSha256 = sha(contents), source = moduleName(file)
          // Inspect original source before esbuild can remove type-only or
          // unused imports, and before a reviewed framework adapter rewrites
          // anything. A symlink/package alias to an adapter is private too.
          const original = readTree(file, contents, buildId), originalImports = []
          function inspectOriginal(node) {
            let specifier, kind
            if ((ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) && node.moduleSpecifier) {
              assert(!node.attributes && !node.assertClause, 'static import attributes unsupported')
              specifier = literal(node.moduleSpecifier); kind = 'import-statement'
            } else if (ts.isImportEqualsDeclaration(node) && ts.isExternalModuleReference(node.moduleReference)) {
              specifier = literal(node.moduleReference.expression); kind = 'require-call'
            } else if (ts.isCallExpression(node) && node.expression.kind === ts.SyntaxKind.ImportKeyword) {
              if (node.arguments.length === 1) { specifier = literal(node.arguments[0]); kind = 'dynamic-import' }
            } else if (ts.isCallExpression(node) && ts.isIdentifier(node.expression) && node.expression.text === 'require') {
              if (node.arguments.length === 1) { specifier = literal(node.arguments[0]); kind = 'require-call' }
            }
            if (specifier !== undefined && specifier !== null) {
              const testEntryImport = specifier === '__QUOD_TEST_ENTRY__' && file === entryFile &&
                entry === 'runner.mjs' && testFile && kind === 'dynamic-import'
              assert(testEntryImport || !privateSpecifier(specifier), 'original source requests private managed namespace')
              if (testEntryImport) fact('original', {importer: file, path: specifier, kind}, moduleName(testFile), 'test-entry')
              if (!testEntryImport) {
                if (isNative(specifier)) {
                  const clause = ts.isImportDeclaration(node) && node.importClause
                  assert(isALS(specifier) && kind === 'import-statement' && clause && !clause.name &&
                    clause.namedBindings && ts.isNamedImports(clause.namedBindings) &&
                    clause.namedBindings.elements.length > 0 && clause.namedBindings.elements.every(element =>
                      (element.propertyName || element.name).text === 'AsyncLocalStorage'),
                  'only a named AsyncLocalStorage import is supported: ' + specifier)
                  if (file !== prelude) publicALS.add(file)
                  fact('original', {importer: file, path: specifier, kind}, file === prelude ? 'node:async_hooks' : '/virtual/public-async-local-storage',
                    file === prelude ? 'native-als' : 'public-als')
                } else originalImports.push({specifier, kind})
              }
            }
            ts.forEachChild(node, inspectOriginal)
          }
          inspectOriginal(original)
          for (const {specifier, kind} of originalImports) {
            const resolved = await ordinaryResolution({path: specifier, importer: file, resolveDir: path.dirname(file), kind})
            assert(!resolved.errors?.length, 'original module cannot be resolved: ' + specifier)
            assert(!inside(root, resolved.path) || privateAdapterAllowed(file, resolved.path, specifier, kind),
              'original source resolves to a private managed adapter: ' + specifier)
            fact('original', {importer: file, path: specifier, kind}, resolved.path, 'ordinary')
          }
          if (/\/node_modules\/(?:zod|zod-4\.[0-6])\/v4\/core\/util\.js$/.test(slash(file))) {
            const expectedProbe = zodUtilAdapters.get(sourceSha256)
            assert(expectedProbe, 'unreviewed Zod optional-evaluator probe module')
            const statements = original.statements.filter(statement => ts.isVariableStatement(statement) &&
              statement.declarationList.declarations.some(declaration => ts.isIdentifier(declaration.name) && declaration.name.text === 'allowsEval'))
            assert.equal(statements.length, 1, 'Zod allowsEval declaration changed')
            const statement = statements[0], start = statement.getStart(original), end = statement.getEnd()
            assert.equal(sha(contents.slice(start, end)), expectedProbe, 'Zod optional-evaluator probe changed')
            contents = contents.slice(0, start) + 'export const allowsEval = cached(() => false);' + contents.slice(end)
            adapters.push({source, sourceSha256, policy: 'Exact Zod optional evaluator probe disabled; existing interpreter fallback only; actual eval remains denied',
              probeSha256: expectedProbe, adaptedSha256: sha(contents)})
          }
          if (file === path.join(vitestRoot, 'dist/chunks/spy.DPLvp2J7.js')) {
            assert.equal(sourceSha256, '537be954493014020a2c07df3e6cbc9e8eb3c5524911b19a43b8b4a3db1f4c0c')
            contents = contents.replace('new FinalizationRegistry((ref) => {\n\tREGISTERED_MOCKS.delete(ref);\n})', '{register() {}}')
              .replace('new WeakRef(mock)', '{deref: () => mock}')
            assert(!contents.includes('FinalizationRegistry') && !contents.includes('WeakRef'))
            adapters.push({source, sourceSha256, policy: 'Retain Vitest private mock references for this file lifetime', adaptedSha256: sha(contents)})
          }
          if (file === path.join(vitestRoot, 'dist/chunks/index.OVGXnVRj.js')) {
            assert.equal(sourceSha256, '57c89e884bab20623afc06a58119c70c4f2e06397ae63e961ad0a0810c9a94b5')
            const probe = 'isPresent.Intl = _global.Intl && typeof _global.Intl === "object";'
            assert.equal(contents.split(probe).length, 2)
            contents = contents.replace(probe, 'isPresent.Intl = false; // Quod managed: Intl unsupported')
            adapters.push({source, sourceSha256, policy: 'Disable optional fake-timer Intl integration; test Intl remains denied', adaptedSha256: sha(contents)})
          }
          const tree = readTree(file, contents, buildId), edits = [], identifiers = new Set()
          function collect(node) {
            if (ts.isIdentifier(node)) identifiers.add(node.text)
            ts.forEachChild(node, collect)
          }
          collect(tree)
          let helper = '__quodCompilerDeny_' + sha(source).slice(0, 12)
          while (identifiers.has(helper)) helper += '_'
          const reject = (node, reason) => {
            edits.push({start: node.getStart(tree), end: node.getEnd(), replacement: `${helper}(${JSON.stringify(reason)})`})
            transforms.push({source, offset: node.getStart(tree), policy: reason})
          }
          function visit(node) {
            // Original source may not request the namespace later injected by
            // this compiler. The same rule covers import and export syntax.
            if ((ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) && node.moduleSpecifier) {
              const specifier = literal(node.moduleSpecifier)
              assert(specifier !== reserved, 'project source requests private compiler capabilities')
              if (file !== prelude && isALS(specifier)) {
                const clause = ts.isImportDeclaration(node) && node.importClause
                assert(clause && !clause.name && clause.namedBindings && ts.isNamedImports(clause.namedBindings) &&
                  clause.namedBindings.elements.length > 0 && clause.namedBindings.elements.every(element =>
                    (element.propertyName || element.name).text === 'AsyncLocalStorage'),
                'only a named AsyncLocalStorage import is supported')
                publicALS.add(file)
              }
            }
            if (ts.isCallExpression(node) && node.expression.kind === ts.SyntaxKind.ImportKeyword) {
              assert(node.arguments.length === 1, 'dynamic import attributes/options unsupported')
              const specifier = literal(node.arguments[0])
              if (specifier === null) { reject(node, 'computed module import'); return }
              assert(specifier !== reserved, 'project source requests private compiler capabilities')
            }
            if (!trusted.has(file) && (ts.isCallExpression(node) || ts.isNewExpression(node)) && evaluator(node.expression)) {
              reject(node, 'dynamic code evaluation'); return
            }
            if (ts.isCallExpression(node) && ts.isIdentifier(node.expression) && node.expression.text === 'require' &&
                (node.arguments.length !== 1 || literal(node.arguments[0]) === null)) {
              reject(node, 'computed require'); return
            }
            if (ts.isCallExpression(node) && ts.isPropertyAccessExpression(node.expression) &&
                ts.isIdentifier(node.expression.expression) && node.expression.expression.text === 'require') {
              reject(node, 'require property operation'); return
            }
            if (ts.isCallExpression(node) && metaMember(node.expression, 'glob')) {
              assert.equal(node.arguments.length, 1, 'glob options unsupported')
              assert(ts.isStringLiteral(node.arguments[0]), 'only literal glob is supported')
              const pattern = node.arguments[0].text, dir = path.dirname(file)
              assert(pattern.startsWith('./') || pattern.startsWith('../'), 'glob must be explicitly relative')
              const matches = [...fs.globSync(pattern, {cwd: dir})].map(name => {
                const real = fs.realpathSync(path.resolve(dir, name))
                assert(inside(project, real) && !inside(root, real) && fs.statSync(real).isFile(),
                  'glob resolved outside project files')
                const relative = slash(name)
                return {name: relative.startsWith('../') || relative.startsWith('./') ? relative : './' + relative,
                  target: moduleName(real)}
              }).sort((a, b) => a.name < b.name ? -1 : a.name > b.name ? 1 : 0)
              const names = matches.map(match => match.name)
              // This finite extension can import only the already-closed actual
              // test entry. Preserve every foreign name with its existing sticky
              // denial; a broad glob must not import host configuration or an
              // unrelated test merely because that path is present in its set.
              const admittedTargets = testFile ? matches.filter(match => match.target === moduleName(testFile)) : []
              globs.push({source, pattern, names, matches, admittedTargets})
              const replacement = '{' + matches.map(match => `${JSON.stringify(match.name)}:()=>` +
                (testFile && match.target === moduleName(testFile) ? `import(${JSON.stringify(match.name)})`
                  : `${helper}(${JSON.stringify('lazy module ' + match.name)})`)).join(',') + '}'
              edits.push({start: node.getStart(tree), end: node.getEnd(), replacement})
              transforms.push({source, offset: node.getStart(tree), policy: 'closed lazy glob; actual test entry only'})
              return
            }
            // Do not expose the runtime's module metadata object: aliases,
            // computed access and destructuring can all recover resolve().
            // The one supported glob form above is completely substituted.
            if (importMeta(node)) { reject(node, 'ambient module metadata'); return }
            ts.forEachChild(node, visit)
          }
          visit(tree)
          for (const edit of edits.sort((a, b) => b.start - a.start)) contents = contents.slice(0, edit.start) + edit.replacement + contents.slice(edit.end)
          if (edits.length) {
            assert(!trusted.has(file), 'reviewed runtime adapter unexpectedly requires compiler denial transform')
            injected.add(file)
            contents = `import {deny as ${helper}} from ${JSON.stringify(reserved)};\n` + contents
          }
          sources.push({source, sourceSha256, compiledSourceSha256: sha(contents)})
          return {contents, loader: /\.tsx$/.test(file) ? 'tsx' : /\.[cm]?ts$/.test(file) ? 'ts' : /\.jsx$/.test(file) ? 'jsx' : 'js'}
        })
        builder.onLoad({filter: /\.json$/, namespace: 'file'}, args => {
          const file = fs.realpathSync(args.path), contents = fs.readFileSync(file, 'utf8')
          sources.push({source: moduleName(file), sourceSha256: sha(contents), compiledSourceSha256: sha(contents)})
          return {contents, loader: 'json'}
        })
      }}],
    })
    assert.equal(compiled.outputFiles.length, 1, 'managed preparation must produce one bundle')
    // Successful onLoad callbacks are the only admitted physical module input
    // authority. Reject an esbuild fallback loader or unknown virtual input,
    // even if its output would otherwise pass the final JavaScript AST checks.
    const physicalSources = [], virtualInputs = []
    for (const input of Object.keys(compiled.metafile.inputs)) {
      if (input === '<define:__QUOD_CONFIG__>' || input === 'quod-managed-als:public-async-local-storage') {
        virtualInputs.push(input); continue
      }
      assert(!input.startsWith('<') && !input.includes('\0'), 'unreviewed virtual managed input: ' + input)
      const absolute = path.resolve(project, input), real = fs.realpathSync(absolute)
      assert.equal(absolute, real, 'metafile physical input is not a resolved real path')
      assert(/\.(?:[cm]?[jt]sx?|json)$/.test(real), 'unreviewed physical managed loader: ' + input)
      physicalSources.push(moduleName(real))
    }
    physicalSources.sort(); virtualInputs.sort()
    assert.deepEqual(physicalSources, sources.map(row => row.source).sort(),
      'physical metafile inputs differ from exact onLoad source multiset')
    assert.equal(virtualInputs.includes('quod-managed-als:public-async-local-storage'),
      resolutionFacts.some(row => row.phase === 'emitted' && row.route === 'public-als'), 'unreviewed ALS virtual input')
    const inputCoverage = {schema: 'quod-managed-physical-input-coverage-v1', physicalSources, virtualInputs}
    const bundle = compiled.outputFiles[0].text
    const imports = Object.values(compiled.metafile.outputs).flatMap(output => output.imports)
    assert(imports.every(item => item.external && item.path === 'node:async_hooks'), 'bundle output is not closed')
    const outputTree = readTree('managed-output.mjs', bundle, buildId), externalImports = []
    function inspect(node) {
      assert(!importMeta(node), 'ambient module metadata remains in final bundle')
      // A copied native require can avoid the direct-call shape (for
      // example `const load = require; load(name)`). No such identifier is
      // needed by esbuild's closed, named __commonJS wrapper functions.
      assert(!(ts.isIdentifier(node) && node.text === 'require'), 'native require reference remains in final bundle')
      assert(!(ts.isCallExpression(node) && node.expression.kind === ts.SyntaxKind.ImportKeyword), 'dynamic import remains in final bundle')
      if (ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) {
        if (node.moduleSpecifier) {
          assert(ts.isImportDeclaration(node) && literal(node.moduleSpecifier) === 'node:async_hooks', 'unreviewed final module import/export')
          externalImports.push(literal(node.moduleSpecifier))
        }
      }
      if (ts.isCallExpression(node) || ts.isNewExpression(node)) {
        assert(!evaluator(node.expression), 'dynamic evaluator remains in final bundle')
        assert(!(ts.isIdentifier(node.expression) && /^(?:require|__require\d*)$/.test(node.expression.text)), 'native/dynamic require remains in final bundle')
      }
      ts.forEachChild(node, inspect)
    }
    inspect(outputTree)
    const sort = rows => rows.sort((a, b) => {
      const left = canonicalManagedJSON(a), right = canonicalManagedJSON(b)
      return left < right ? -1 : left > right ? 1 : 0
    })
    sort(globs); sort(adapters); sort(sources); sort(transforms); sort(resolutions); sort(resolutionFacts)
    const sha256 = sha(bundle)
    const identity = {
      schema: 'quod-managed-compile-v1-research', compilerSha256, esbuildVersion, typescriptVersion: ts.version,
      policy: {platform: 'browser', format: 'esm', target: 'es2022', keepNames: true, external: ['node:async_hooks'],
        dynamicCode: 'private-sticky-denial-plus-runtime-constructor-guards',
        importMeta: 'literal-relative-glob-self-entry-only; all-other-access-sticky-denied',
        lazyGlob: 'actual-real-test-entry-only; all-other-matches-sticky-denied', preparationAlwaysRuns: true,
        ...(zodAlias ? {zodAlias, zodAliasPolicy: 'reviewed /^zod(?=\\/|$)/ replacement for every closed dependency'} : {})},
      entry: moduleName(entryFile), testEntry: testFile && moduleName(testFile), bundleSha256: sha256,
      configurationSha256: sha(optionsJSON), moduleNameSetsSha256: sha(canonicalManagedJSON(globs)),
      sources, resolutions, adapters, globs, transforms, resolutionFacts, inputCoverage,
    }
    return {bundle, metadata: compiled.metafile, seconds: (performance.now() - started) / 1000, sha256,
      sourceTreeCache: {...treeCache, retainedEntries: trees.size},
      globs, adapters, identity, identitySha256: sha(canonicalManagedJSON(identity)),
      closure: {finalBundleParsed: true, remainingDynamicImports: 0, remainingDynamicRequires: 0,
        externalImports, privateAdapterImports: 'reviewed entry only',
        nativeImports: 'prelude ALS only; named public ALS uses restricted facade'}}
  }
}
